﻿using HarmonyLib;
using Verse;

namespace PrisonCommons
{
    [HarmonyPatch(typeof(Room), nameof(Room.IsPrisonCell), MethodType.Getter)]
    static class Room_IsPrisonCell_Patch
    {
        public static void Postfix(ref bool __result, Room __instance)
        {
            if (!__result)
            {
                __result = PrisonCommons.IsPrisonCommons(__instance);
            }
        }
    }
}
